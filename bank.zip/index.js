const express = require("express");
const authRouter = require("./auth/auth.controller.js");

const app = express();
app.use(express.json());


app.get("/", (req, res) => {
  res.send("Welcome to homepage");
});


app.use("/auth", authRouter);

app.listen(4000, () => {
  console.log(`Server is running on port 5000`);
});
